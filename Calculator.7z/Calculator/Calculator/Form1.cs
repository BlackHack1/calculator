﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Calculator
{
    public partial class Form1 : Form
    {
        string num1 = string.Empty;
        string num2 = string.Empty;
        string apotelesma;
        char pedioegrafis;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btn1.Click += new EventHandler(btn_Click);
            btn2.Click += new EventHandler(btn_Click);
            btn3.Click += new EventHandler(btn_Click);
            btn4.Click += new EventHandler(btn_Click);
            btn5.Click += new EventHandler(btn_Click);
            btn6.Click += new EventHandler(btn_Click);
            btn7.Click += new EventHandler(btn_Click);
            btn8.Click += new EventHandler(btn_Click);
            btn9.Click += new EventHandler(btn_Click);
            btn0.Click += new EventHandler(btn_Click);
            btntelia.Click += new EventHandler(btn_Click);

        }

        void btn_Click (object sender, EventArgs e)
        {
            try
            {
                Button btn = sender as Button;
                switch (btn.Name)
                {
                    case "btn1":
                        box.Text += "1";
                    break;

                    case "btn2":
                        box.Text += "2";
                    break;

                    case "btn3":
                        box.Text += "3";
                    break;

                    case "btn4":
                        box.Text += "4";
                    break;

                    case "btn5":
                        box.Text += "5";
                    break;

                    case "btn6":
                        box.Text += "6";
                    break;

                    case "btn7":
                        box.Text += "7";
                    break;

                    case "btn8":
                        box.Text += "8";
                    break;

                    case "btn9":
                        box.Text += "9";
                    break;

                    case "btn0":
                        box.Text += "0";
                    break;

                    case "btntelia":
                        box.Text += ".";
                    break;                  
                }
            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://carcinos.com");
        }

        private void bison_Click(object sender, EventArgs e)
        {
            num2 = box.Text;

            float n1, n2;
            float.TryParse(num1, out n1);
            float.TryParse(num2, out n2);

            switch (pedioegrafis)
            {
                case '+':
                    apotelesma = (n1 + n2).ToString();
                    break;
                case '-':
                    apotelesma = (n1 - n2).ToString();
                    break;
                case '*':
                    apotelesma = (n1 * n2).ToString();
                    break;
                case '/':
                   if (n2 != 0)
                    {
                        apotelesma = (n1 / n2).ToString();
                    }
                    else
                    {
                        MessageBox.Show("Η ΠΡΑΞΗ ΕΙΝΑΙ ΑΔΥΝΑΤΗ");
                    }
                    break;
            }

            box.Text = apotelesma.ToString();
        }

        private void bsin_Click(object sender, EventArgs e)
        {
            num1 = box.Text;
            pedioegrafis = '+';
            box.Text = pedioegrafis.ToString();
        }

        private void bmion_Click(object sender, EventArgs e)
        {
            num1 = box.Text;
            pedioegrafis = '-';
            box.Text = pedioegrafis.ToString();
        }

        private void bepi_Click(object sender, EventArgs e)
        {
            num1 = box.Text;
            pedioegrafis = '*';
            box.Text = pedioegrafis.ToString();
        }

        private void bdia_Click(object sender, EventArgs e)
        {
            num1 = box.Text;
            pedioegrafis = '/';
            box.Text = pedioegrafis.ToString();
        }

        private void bclear_Click(object sender, EventArgs e)
        {
            box.Text = string.Empty;
            num1 = string.Empty;
            num2 = string.Empty;
        }
    }
}
