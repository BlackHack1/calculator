﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.box = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.bmion = new System.Windows.Forms.Button();
            this.bsin = new System.Windows.Forms.Button();
            this.bclear = new System.Windows.Forms.Button();
            this.bdia = new System.Windows.Forms.Button();
            this.bepi = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.btn0 = new System.Windows.Forms.Button();
            this.btntelia = new System.Windows.Forms.Button();
            this.bison = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // box
            // 
            this.box.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.box.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.box.ForeColor = System.Drawing.Color.Lime;
            this.box.Location = new System.Drawing.Point(12, 12);
            this.box.Name = "box";
            this.box.Size = new System.Drawing.Size(378, 26);
            this.box.TabIndex = 0;
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Black;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.ForeColor = System.Drawing.Color.Lime;
            this.btn1.Location = new System.Drawing.Point(12, 44);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(35, 29);
            this.btn1.TabIndex = 1;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.Black;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.ForeColor = System.Drawing.Color.Lime;
            this.btn2.Location = new System.Drawing.Point(78, 44);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(35, 29);
            this.btn2.TabIndex = 2;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.Black;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.ForeColor = System.Drawing.Color.Lime;
            this.btn3.Location = new System.Drawing.Point(147, 44);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(35, 29);
            this.btn3.TabIndex = 3;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.Black;
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn4.ForeColor = System.Drawing.Color.Lime;
            this.btn4.Location = new System.Drawing.Point(12, 104);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(35, 29);
            this.btn4.TabIndex = 4;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.Black;
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5.ForeColor = System.Drawing.Color.Lime;
            this.btn5.Location = new System.Drawing.Point(78, 104);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(35, 29);
            this.btn5.TabIndex = 5;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.Black;
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn6.ForeColor = System.Drawing.Color.Lime;
            this.btn6.Location = new System.Drawing.Point(147, 104);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(35, 29);
            this.btn6.TabIndex = 6;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.Black;
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn7.ForeColor = System.Drawing.Color.Lime;
            this.btn7.Location = new System.Drawing.Point(12, 164);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(35, 29);
            this.btn7.TabIndex = 7;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.Black;
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn8.ForeColor = System.Drawing.Color.Lime;
            this.btn8.Location = new System.Drawing.Point(78, 164);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(35, 29);
            this.btn8.TabIndex = 8;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.Black;
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn9.ForeColor = System.Drawing.Color.Lime;
            this.btn9.Location = new System.Drawing.Point(147, 164);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(35, 29);
            this.btn9.TabIndex = 9;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.button6_Click);
            // 
            // bmion
            // 
            this.bmion.BackColor = System.Drawing.Color.Black;
            this.bmion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bmion.ForeColor = System.Drawing.Color.Lime;
            this.bmion.Location = new System.Drawing.Point(355, 114);
            this.bmion.Name = "bmion";
            this.bmion.Size = new System.Drawing.Size(35, 29);
            this.bmion.TabIndex = 12;
            this.bmion.Text = "-";
            this.bmion.UseVisualStyleBackColor = false;
            this.bmion.Click += new System.EventHandler(this.bmion_Click);
            // 
            // bsin
            // 
            this.bsin.BackColor = System.Drawing.Color.Black;
            this.bsin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bsin.ForeColor = System.Drawing.Color.Lime;
            this.bsin.Location = new System.Drawing.Point(355, 79);
            this.bsin.Name = "bsin";
            this.bsin.Size = new System.Drawing.Size(35, 29);
            this.bsin.TabIndex = 11;
            this.bsin.Text = "+";
            this.bsin.UseVisualStyleBackColor = false;
            this.bsin.Click += new System.EventHandler(this.bsin_Click);
            // 
            // bclear
            // 
            this.bclear.BackColor = System.Drawing.Color.Black;
            this.bclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bclear.ForeColor = System.Drawing.Color.Lime;
            this.bclear.Location = new System.Drawing.Point(355, 44);
            this.bclear.Name = "bclear";
            this.bclear.Size = new System.Drawing.Size(35, 29);
            this.bclear.TabIndex = 10;
            this.bclear.Text = "C";
            this.bclear.UseVisualStyleBackColor = false;
            this.bclear.Click += new System.EventHandler(this.bclear_Click);
            // 
            // bdia
            // 
            this.bdia.BackColor = System.Drawing.Color.Black;
            this.bdia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bdia.ForeColor = System.Drawing.Color.Lime;
            this.bdia.Location = new System.Drawing.Point(355, 185);
            this.bdia.Name = "bdia";
            this.bdia.Size = new System.Drawing.Size(35, 29);
            this.bdia.TabIndex = 14;
            this.bdia.Text = "/";
            this.bdia.UseVisualStyleBackColor = false;
            this.bdia.Click += new System.EventHandler(this.bdia_Click);
            // 
            // bepi
            // 
            this.bepi.BackColor = System.Drawing.Color.Black;
            this.bepi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bepi.ForeColor = System.Drawing.Color.Lime;
            this.bepi.Location = new System.Drawing.Point(355, 149);
            this.bepi.Name = "bepi";
            this.bepi.Size = new System.Drawing.Size(35, 29);
            this.bepi.TabIndex = 13;
            this.bepi.Text = "*";
            this.bepi.UseVisualStyleBackColor = false;
            this.bepi.Click += new System.EventHandler(this.bepi_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.linkLabel1.ForeColor = System.Drawing.Color.Lime;
            this.linkLabel1.LinkColor = System.Drawing.Color.Lime;
            this.linkLabel1.Location = new System.Drawing.Point(9, 260);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(123, 16);
            this.linkLabel1.TabIndex = 15;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "BlackHack 2016 ";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.Black;
            this.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn0.ForeColor = System.Drawing.Color.Lime;
            this.btn0.Location = new System.Drawing.Point(78, 211);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(35, 29);
            this.btn0.TabIndex = 16;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            // 
            // btntelia
            // 
            this.btntelia.BackColor = System.Drawing.Color.Black;
            this.btntelia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btntelia.ForeColor = System.Drawing.Color.Lime;
            this.btntelia.Location = new System.Drawing.Point(12, 211);
            this.btntelia.Name = "btntelia";
            this.btntelia.Size = new System.Drawing.Size(35, 29);
            this.btntelia.TabIndex = 17;
            this.btntelia.Text = ".";
            this.btntelia.UseVisualStyleBackColor = false;
            // 
            // bison
            // 
            this.bison.BackColor = System.Drawing.Color.Black;
            this.bison.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bison.ForeColor = System.Drawing.Color.Lime;
            this.bison.Location = new System.Drawing.Point(147, 211);
            this.bison.Name = "bison";
            this.bison.Size = new System.Drawing.Size(35, 29);
            this.bison.TabIndex = 18;
            this.bison.Text = "=";
            this.bison.UseVisualStyleBackColor = false;
            this.bison.Click += new System.EventHandler(this.bison_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.ClientSize = new System.Drawing.Size(398, 285);
            this.Controls.Add(this.bison);
            this.Controls.Add(this.btntelia);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.bdia);
            this.Controls.Add(this.bepi);
            this.Controls.Add(this.bmion);
            this.Controls.Add(this.bsin);
            this.Controls.Add(this.bclear);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.box);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox box;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button bmion;
        private System.Windows.Forms.Button bsin;
        private System.Windows.Forms.Button bclear;
        private System.Windows.Forms.Button bdia;
        private System.Windows.Forms.Button bepi;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btntelia;
        private System.Windows.Forms.Button bison;
    }
}

